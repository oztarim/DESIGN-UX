This is a mobile app prototype built with Proto.io mobile app prototyping tool.

Overview

Need an application that gives an organized work environment, tracks activity, shows daily counts and avoids excess inventory.

Please use Prototype.html to access application and resize screen if needed.

